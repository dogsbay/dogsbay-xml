set "CLASSPATH=%CLASSPATH%;%DITA_HOME%\plugins\com.elovirta.pdf\lib\pdf-generator-0.8.0.jar"
